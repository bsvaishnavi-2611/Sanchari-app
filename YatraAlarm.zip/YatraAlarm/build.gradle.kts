// Top-level build file. Plugin versions live here; module configs apply them.
plugins {
    id("com.android.application")    version "8.6.1" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
