# YatraAlarm

A demo destination-alarm Android app for Karnataka, **with no Google Maps API key required.**

The map is rendered by **OSMDroid** using free OpenStreetMap tiles. The app ships with **10 hardcoded Karnataka destinations** (Bengaluru, Tumakuru, Kunigal, Mysuru, Mandya, Davangere, Chitradurga, Hampi, Coorg, Mangaluru) so you can demo the full track-and-arrive flow on a fresh install with zero setup.

## What you need

- Android Studio Hedgehog or newer
- Android SDK API 34
- JDK 17 (bundled with Studio as `jbr-17`)

That's it. No Google Cloud account, no API key, no billing.

## Run

1. **File → Open** → pick the `YatraAlarm` folder.
2. Wait for Gradle sync (downloads AGP 8.6.1, Kotlin 1.9.24, Compose, OSMDroid).
3. Pick an Android 8.0+ emulator or device.
4. **Run ▶**.

First launch asks for **Notifications** and **Location** permissions. Grant both for the best demo, but the app works without either.

## How the demo flows

When the app opens you see:

- An OpenStreetMap view of Karnataka with all 10 destinations as pins.
- Below the map, a scrollable list of the 10 destinations with distance from your simulated position (Bengaluru by default).

For each destination you can:

- **Track** — start watching this destination. A pill appears at the top of the map showing "Tracking *name* — *N* km", and a soft circle on the map shows the arrival radius (500 m by default).
- **Simulate** — teleport the simulated user marker to that destination so the arrival alarm fires immediately. This is the magic button that makes the full demo work indoors with no GPS movement.
- **Stop** — stop tracking.

When the simulated (or real) location enters the destination's radius, the app:

1. Plays a high-priority notification with sound and vibration.
2. Shows a full-screen "You have arrived!" dialog with a shaking bell.
3. Stops tracking.

## Why no Google Maps key

This build deliberately avoids Google Maps Platform so the app can be installed and demoed by anyone without:

- Creating a Google Cloud project
- Enabling billing
- Generating, restricting, and pasting an API key
- Re-signing on a new dev machine

Instead it uses:

- **OSMDroid 6.1.18** — pulls OpenStreetMap tiles directly from the public OSM tile servers. No key required.
- **Hardcoded destination list** — no Places API needed for search, because the destinations are baked in.
- **Haversine distance math** — no Geocoding API needed; we compute distance ourselves.
- **FusedLocationProvider (optional)** — part of Play Services and works without any key for real GPS, but the demo also runs with a simulated location, so this is genuinely optional.

The OSM tile usage policy requires a unique User-Agent. We set it to the package name in `YatraApplication.onCreate()`. For heavier use you should host your own tile server or use a paid tile provider, but for a single-app demo this is well within fair-use limits.

## What's NOT in this build (and why)

- **No login / signup** — single-user demo, no accounts.
- **No backend** — destinations are a `val` in `data/Destinations.kt`.
- **No foreground service** — tracking only runs while the app is in the foreground. For a production app you'd add a foreground service with `foregroundServiceType="location"` so the alarm fires with the screen off.
- **No Places autocomplete** — list is hardcoded. If you want the same UX as DestinationAlarm/Sanchari, the simplest add is a free-text search box that filters the local list by name.

## Project layout

```
YatraAlarm/
├── settings.gradle.kts
├── build.gradle.kts            (root)
├── gradle.properties
├── README.md
└── app/
    ├── build.gradle.kts
    ├── proguard-rules.pro
    └── src/main/
        ├── AndroidManifest.xml
        ├── res/
        │   ├── values/{colors,strings,themes}.xml
        │   ├── xml/network_security_config.xml
        │   ├── drawable/ic_launcher_*.xml
        │   └── mipmap-anydpi-v26/ic_launcher{,_round}.xml
        └── java/com/yatra/alarm/
            ├── YatraApplication.kt    (OSMDroid config + notification channel)
            ├── MainActivity.kt        (single Compose host)
            ├── data/Destinations.kt   (10 Karnataka destinations)
            ├── service/AlarmController.kt   (notification + vibration helper)
            ├── ui/
            │   ├── theme/{Color,Theme}.kt
            │   ├── components/{OsmMap,DestinationRow,AlarmDialog}.kt
            │   └── MapScreen.kt       (the only screen)
            └── util/Distance.kt       (Haversine)
```

## Adding more destinations

Edit `app/src/main/java/com/yatra/alarm/data/Destinations.kt` and append to the list. The `id` field must be unique. Everything else (the map, the list, the distance calculations) updates automatically.

```kotlin
Destination(11, "Jog Falls", "Shimoga", "Second-highest plunge waterfall in India.", 14.2287, 74.8120),
```

## Troubleshooting

**Map shows grey tiles.**
First-time tile download needs internet. Make sure the device has a working network. Tiles cache locally after the first view.

**"Location permission denied" — alarm doesn't trigger from real GPS.**
The simulated location ("Simulate" buttons) bypasses GPS entirely, so the demo still works. To use real GPS, grant Fine Location permission from system Settings → Apps → YatraAlarm.

**Notification not showing on Android 13+.**
Grant the POST_NOTIFICATIONS permission when prompted, or from Settings → Apps → YatraAlarm → Notifications.

**Tile server hiccups.**
OSMDroid retries automatically. If you hammer the tile server during testing, it may rate-limit you for a few minutes.
