package com.yatra.alarm

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import org.osmdroid.config.Configuration

class YatraApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // OSMDroid politeness: a unique User-Agent is required by the OpenStreetMap
        // tile usage policy. Without it, requests are rate-limited or blocked.
        val osmPrefs = getSharedPreferences("osmdroid", Context.MODE_PRIVATE)
        Configuration.getInstance().apply {
            load(applicationContext, osmPrefs)
            userAgentValue = packageName
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    ALARM_CHANNEL_ID,
                    getString(R.string.alarm_channel_name),
                    NotificationManager.IMPORTANCE_HIGH,
                ).apply {
                    description = getString(R.string.alarm_channel_desc)
                    enableVibration(true)
                }
            )
        }
    }

    companion object { const val ALARM_CHANNEL_ID = "yatra_arrival" }
}
