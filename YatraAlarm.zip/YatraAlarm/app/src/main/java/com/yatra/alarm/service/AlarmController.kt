package com.yatra.alarm.service

import android.Manifest
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.yatra.alarm.MainActivity
import com.yatra.alarm.R
import com.yatra.alarm.YatraApplication

/** Fires the arrival notification + vibration. No background service for the demo. */
object AlarmController {
    fun fire(ctx: Context, destinationName: String) {
        val open = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notif = NotificationCompat.Builder(ctx, YatraApplication.ALARM_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentTitle("\uD83D\uDD14 You have arrived!")
            .setContentText("You've reached $destinationName")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // App will skip the system tray notification but still vibrate + show the in-app alarm.
        } else {
            ctx.getSystemService(NotificationManager::class.java).notify(NOTIF_ID, notif)
        }

        val vib = ContextCompat.getSystemService(ctx, Vibrator::class.java)
        vib?.vibrate(
            VibrationEffect.createWaveform(longArrayOf(0, 400, 150, 400, 150, 800), -1)
        )
    }

    private const val NOTIF_ID = 7711
}
