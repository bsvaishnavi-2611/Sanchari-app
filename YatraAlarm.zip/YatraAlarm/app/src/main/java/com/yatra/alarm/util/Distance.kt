package com.yatra.alarm.util

import kotlin.math.*

/** Great-circle distance in metres between two lat/lng points (Haversine). */
fun distanceMetres(lat1: Double, lng1: Double, lat2: Double, lng2: Double): Double {
    val r = 6_371_000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLng = Math.toRadians(lng2 - lng1)
    val a = sin(dLat / 2).pow(2.0) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLng / 2).pow(2.0)
    return 2 * r * asin(min(1.0, sqrt(a)))
}
