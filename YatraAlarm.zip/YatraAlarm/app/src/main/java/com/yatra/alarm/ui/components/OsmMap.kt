package com.yatra.alarm.ui.components

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.yatra.alarm.data.Destination
import com.yatra.alarm.data.KarnatakaDestinations
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polygon

/**
 * OpenStreetMap-backed map. No API key required; tiles come from the public
 * OSM tile servers, with a per-app User-Agent set in YatraApplication.
 */
@Composable
fun OsmMap(
    destinations: List<Destination>,
    userLat: Double,
    userLng: Double,
    trackedId: Int?,
    modifier: Modifier = Modifier,
    onMarkerTap: (Destination) -> Unit = {},
) {
    AndroidView(
        modifier = modifier,
        factory = { ctx -> buildMapView(ctx) },
        update  = { map ->
            // Wipe + redraw overlays each recomposition. Cheap for ~10 markers.
            map.overlays.clear()

            destinations.forEach { dest ->
                map.overlays.add(destinationMarker(map, dest, isTracked = (dest.id == trackedId), onMarkerTap))
                if (dest.id == trackedId) {
                    map.overlays.add(radiusCircle(dest))
                }
            }
            map.overlays.add(userMarker(map, userLat, userLng))
            map.invalidate()
        },
    )
}

private fun buildMapView(ctx: Context): MapView = MapView(ctx).apply {
    setTileSource(TileSourceFactory.MAPNIK)
    setMultiTouchControls(true)
    setUseDataConnection(true)
    minZoomLevel  = 4.0
    maxZoomLevel  = 19.0
    controller.setZoom(KarnatakaDestinations.initialZoom)
    controller.setCenter(GeoPoint(KarnatakaDestinations.mapCenterLat, KarnatakaDestinations.mapCenterLng))
}

private fun destinationMarker(
    map: MapView, d: Destination, isTracked: Boolean,
    onTap: (Destination) -> Unit,
): Marker = Marker(map).apply {
    position = GeoPoint(d.lat, d.lng)
    title    = d.name
    snippet  = d.region + " — " + d.description
    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
    setOnMarkerClickListener { _, _ ->
        onTap(d); showInfoWindow(); true
    }
    if (isTracked) {
        // Pin tinted differently for the tracked destination
        alpha = 1.0f
    }
}

private fun userMarker(map: MapView, lat: Double, lng: Double): Marker = Marker(map).apply {
    position = GeoPoint(lat, lng)
    title    = "You are here"
    setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
    alpha    = 0.85f
}

private fun radiusCircle(d: Destination): Polygon = Polygon().apply {
    points = circlePoints(d.lat, d.lng, d.radiusM.toDouble())
    fillPaint.color   = 0x33E8744C // semi-transparent terracotta
    outlinePaint.color = 0xFFE8744C.toInt()
    outlinePaint.strokeWidth = 4f
}

private fun circlePoints(lat: Double, lng: Double, radiusM: Double, n: Int = 64): List<GeoPoint> {
    val r = 6_371_000.0
    val d = radiusM / r
    val lat1 = Math.toRadians(lat); val lng1 = Math.toRadians(lng)
    return (0 until n).map { i ->
        val brng = Math.toRadians(360.0 * i / n)
        val lat2 = Math.asin(Math.sin(lat1) * Math.cos(d) + Math.cos(lat1) * Math.sin(d) * Math.cos(brng))
        val lng2 = lng1 + Math.atan2(
            Math.sin(brng) * Math.sin(d) * Math.cos(lat1),
            Math.cos(d) - Math.sin(lat1) * Math.sin(lat2),
        )
        GeoPoint(Math.toDegrees(lat2), Math.toDegrees(lng2))
    } + GeoPoint(lat, lng) // close the ring back to centre direction
}
