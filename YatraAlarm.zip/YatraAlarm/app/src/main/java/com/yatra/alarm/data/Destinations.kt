package com.yatra.alarm.data

data class Destination(
    val id: Int,
    val name: String,
    val region: String,
    val description: String,
    val lat: Double,
    val lng: Double,
    val radiusM: Int = 500,
)

/** 10 well-known places across Karnataka. Used as the demo dataset. */
object KarnatakaDestinations {
    val all: List<Destination> = listOf(
        Destination(1,  "Vidhana Soudha",     "Bengaluru",   "Seat of the Karnataka legislature.",                12.9794, 77.5912),
        Destination(2,  "Siddaganga Mutt",    "Tumakuru",    "Historic monastery and educational centre.",        13.3392, 77.1140),
        Destination(3,  "Kunigal Lake",       "Kunigal",     "Scenic lake town on the Bengaluru-Mangaluru route.", 13.0259, 77.0264),
        Destination(4,  "Mysore Palace",      "Mysuru",      "Royal palace, lit up at night during Dasara.",      12.3052, 76.6552),
        Destination(5,  "Mandya Town",        "Mandya",      "Sugar bowl of Karnataka, on the KRS dam belt.",     12.5242, 76.8956),
        Destination(6,  "Davangere Center",   "Davangere",   "Manchester of Karnataka, famed for benne dosa.",    14.4644, 75.9218),
        Destination(7,  "Chitradurga Fort",   "Chitradurga", "Seven-walled hill fort with rock-cut passages.",    14.2226, 76.4019),
        Destination(8,  "Virupaksha Temple",  "Hampi",       "UNESCO World Heritage temple in Vijayanagara ruins.", 15.3350, 76.4600),
        Destination(9,  "Madikeri Town",      "Coorg",       "Hill station, coffee plantations, Raja's Seat.",    12.4244, 75.7382),
        Destination(10, "Mangalore Beach",    "Mangaluru",   "Tannirbhavi beach, coastal port city.",             12.9141, 74.8560),
    )

    /** Geographic centre used to frame the initial map view. */
    val mapCenterLat = 13.7
    val mapCenterLng = 76.4
    val initialZoom  = 7.0
}
