package com.yatra.alarm.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.yatra.alarm.data.Destination
import com.yatra.alarm.data.KarnatakaDestinations
import com.yatra.alarm.service.AlarmController
import com.yatra.alarm.ui.components.*
import com.yatra.alarm.ui.theme.*
import com.yatra.alarm.util.distanceMetres

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen() {
    val ctx = LocalContext.current
    val destinations = remember { KarnatakaDestinations.all }

    // Default user location: Bengaluru. Simulated by default; tap Simulate on any
    // row to teleport here for the demo, or grant location permission for real GPS.
    var userLat by remember { mutableStateOf(12.9716) }
    var userLng by remember { mutableStateOf(77.5946) }

    var trackedId by remember { mutableStateOf<Int?>(null) }
    var firedFor  by remember { mutableStateOf<Int?>(null) }   // dedupe alarm per tracked id
    var alarmDest by remember { mutableStateOf<Destination?>(null) }

    val tracked = destinations.firstOrNull { it.id == trackedId }

    // Distance map (kept fresh per recomposition; tiny dataset).
    val distances: Map<Int, Double> = destinations.associate { d ->
        d.id to distanceMetres(userLat, userLng, d.lat, d.lng)
    }

    // Alarm trigger
    LaunchedEffect(trackedId, userLat, userLng) {
        val t = tracked ?: return@LaunchedEffect
        val dist = distances[t.id] ?: return@LaunchedEffect
        if (dist <= t.radiusM && firedFor != t.id) {
            firedFor = t.id
            alarmDest = t
            AlarmController.fire(ctx, t.name)
        }
    }

    // Optional: ask for notification + location permissions
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()) { /* result ignored for demo */ }
    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()) { /* result ignored for demo */ }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val needs = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needs += Manifest.permission.ACCESS_FINE_LOCATION
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            needs += Manifest.permission.ACCESS_COARSE_LOCATION
        if (needs.isNotEmpty()) locationPermission.launch(needs.toTypedArray())
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("YatraAlarm",
                             fontSize = 22.sp,
                             fontStyle = FontStyle.Italic,
                             fontWeight = FontWeight.ExtraBold,
                             color = OceanDeep)
                        Text("Karnataka destinations • demo without API keys",
                             style = MaterialTheme.typography.bodySmall,
                             color = InkSoft)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Sand),
            )
        },
        containerColor = Sand,
    ) { padding ->
        Column(Modifier.padding(padding).fillMaxSize()) {
            // Map
            Box(
                Modifier.fillMaxWidth().weight(1f).background(Ocean.copy(alpha = 0.1f)),
            ) {
                OsmMap(
                    destinations = destinations,
                    userLat = userLat,
                    userLng = userLng,
                    trackedId = trackedId,
                    modifier = Modifier.fillMaxSize(),
                )
                // Tracking pill
                tracked?.let { t ->
                    Surface(
                        color = OceanDeep,
                        shape = RoundedCornerShape(999.dp),
                        modifier = Modifier.align(Alignment.TopCenter).padding(top = 12.dp),
                    ) {
                        Row(
                            Modifier.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Box(Modifier.size(8.dp).clip(RoundedCornerShape(50)).background(Sun))
                            Text("Tracking " + t.name, color = Paper, style = MaterialTheme.typography.bodySmall)
                            val d = distances[t.id] ?: 0.0
                            val km = if (d < 1_000) d.toInt().toString() + " m" else String.format("%.1f km", d / 1_000)
                            Text(km, color = Sun, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }

            // Saved destinations list
            Surface(color = Paper, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Filled.MyLocation, contentDescription = null, tint = Ocean)
                        Text("Saved destinations • " + destinations.size,
                             style = MaterialTheme.typography.labelSmall, color = Ocean,
                             fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.heightIn(max = 360.dp),
                    ) {
                        items(destinations, key = { it.id }) { d ->
                            DestinationRow(
                                dest      = d,
                                distanceM = distances[d.id],
                                isTracked = (d.id == trackedId),
                                onTrack   = { trackedId = d.id; firedFor = null },
                                onStop    = { trackedId = null; firedFor = null },
                                onSimulate = {
                                    // Teleport user to (almost) the destination so the alarm fires.
                                    userLat = d.lat + 0.0005
                                    userLng = d.lng + 0.0005
                                    if (trackedId == null) trackedId = d.id
                                    firedFor = null
                                },
                            )
                        }
                    }
                }
            }
        }

        alarmDest?.let { dest ->
            ArrivalAlarmDialog(
                destinationName = dest.name,
                onDismiss = {
                    alarmDest = null
                    trackedId = null
                },
            )
        }
    }
}
