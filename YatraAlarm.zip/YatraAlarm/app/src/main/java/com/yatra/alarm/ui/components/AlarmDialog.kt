package com.yatra.alarm.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.yatra.alarm.ui.theme.*

@Composable
fun ArrivalAlarmDialog(destinationName: String, onDismiss: () -> Unit) {
    val infinite = rememberInfiniteTransition(label = "bell")
    val angle by infinite.animateFloat(
        initialValue = -15f, targetValue = 15f,
        animationSpec = infiniteRepeatable(tween(220), RepeatMode.Reverse),
        label = "shake",
    )
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = MaterialTheme.shapes.large, color = Paper) {
            Column(
                Modifier.padding(28.dp).widthIn(max = 380.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("\uD83D\uDD14", fontSize = 56.sp, modifier = Modifier.rotate(angle))
                Spacer(Modifier.height(8.dp))
                Text("You have arrived!", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TerracottaDeep)
                Spacer(Modifier.height(6.dp))
                Text(destinationName, color = InkSoft, textAlign = TextAlign.Center)
                Spacer(Modifier.height(20.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Terracotta),
                ) { Text("Dismiss") }
            }
        }
    }
}
