package com.yatra.alarm.ui.theme

import androidx.compose.ui.graphics.Color

val Terracotta     = Color(0xFFE8744C)
val TerracottaDeep = Color(0xFFC4502A)
val Ocean          = Color(0xFF0D6E8C)
val OceanDeep      = Color(0xFF074559)
val OceanNight     = Color(0xFF042F3D)
val Sand           = Color(0xFFF6EFE1)
val Sun            = Color(0xFFFFC857)
val Ink            = Color(0xFF1B2A35)
val InkSoft        = Color(0xFF3A4A57)
val Paper          = Color(0xFFFFFFFF)
