package com.yatra.alarm.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PinDrop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.yatra.alarm.data.Destination
import com.yatra.alarm.ui.theme.*

@Composable
fun DestinationRow(
    dest: Destination,
    distanceM: Double?,
    isTracked: Boolean,
    onTrack: () -> Unit,
    onStop:  () -> Unit,
    onSimulate: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = if (isTracked) Sand else Paper,
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isTracked) Terracotta else Ocean.copy(alpha = 0.15f),
        ),
        shadowElevation = 2.dp,
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(36.dp).clip(RoundedCornerShape(50))
                        .background(if (isTracked) Terracotta else Ocean),
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.Place, contentDescription = null, tint = Paper)
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(dest.name, fontWeight = FontWeight.SemiBold, color = OceanDeep)
                    Text(dest.region, style = MaterialTheme.typography.bodySmall, color = InkSoft)
                }
                if (distanceM != null) {
                    Text(
                        formatDistance(distanceM),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (distanceM <= dest.radiusM) Terracotta else InkSoft,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(dest.description, style = MaterialTheme.typography.bodySmall, color = InkSoft)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!isTracked) {
                    OutlinedButton(onClick = onTrack, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Track")
                    }
                } else {
                    Button(
                        onClick = onStop,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = TerracottaDeep),
                    ) {
                        Icon(Icons.Filled.Stop, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Stop")
                    }
                }
                OutlinedButton(
                    onClick = onSimulate,
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.PinDrop, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Simulate")
                }
            }
        }
    }
}

private fun formatDistance(m: Double): String =
    if (m < 1_000) m.toInt().toString() + " m" else String.format("%.1f km", m / 1_000)
