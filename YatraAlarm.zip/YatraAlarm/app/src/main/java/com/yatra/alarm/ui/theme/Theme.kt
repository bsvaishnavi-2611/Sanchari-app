package com.yatra.alarm.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val Light = lightColorScheme(
    primary          = Terracotta,    onPrimary   = Paper,
    primaryContainer = Sun,            onPrimaryContainer = OceanDeep,
    secondary        = Ocean,          onSecondary = Paper,
    tertiary         = TerracottaDeep,
    background       = Sand,           onBackground = Ink,
    surface          = Paper,          onSurface    = Ink,
    surfaceVariant   = Sand,           onSurfaceVariant = InkSoft,
    error            = TerracottaDeep, onError      = Paper,
)

@Composable
fun YatraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Light, content = content)
}
